<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Detections extends Model
{
    //
}
